<!DOCTYPE html>
<html>

<head>
    <title>Login</title>
    <script src="vendor/jquery/jquery-3.3.1.js" type="text/javascript"></script>
    <style>
        body {
            background-color: lightgray;
            margin: 110px 160px;
            font-size: 16px;
            color: #666;
            font-weight: 400;
            font-family: 'Lato', sans-serif;
        }

        .phppot-container {
            background-color: white;
            max-width: 340px;
            margin: 0 auto;
            position: relative;
            top: 80px;
            padding-bottom: 30px;
            border-radius: 5px;
            box-shadow: 0 5px 50px rgba(0, 0, 0, 0.4);
            text-align: center;
        }

        .phppot-container .box-header {
            background-color: #665851;
            margin-top: 0;
            border-radius: 5px 5px 0 0;
            color: white;
            padding: 1rem;
        }

        .login-signup {
            padding: 1rem;
            margin-bottom: 1rem;
            font-size: 16px;
        }

        .signup-heading {
            margin-bottom: 1rem;
            font-size: 24px;
        }

        .form-label {
            margin-bottom: 0.5rem;
            font-size: 16px;
        }

        .input-box-330 {
            margin-bottom: 1rem;
            width: 90%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .btn {
            margin-top: 0px;
            border: 1px solid black;
            border-radius: 2px;
            color: black;
            padding: 10px;
            text-transform: uppercase;
            font-weight: 500;
            font-size: 0.8em;
            letter-spacing: 1px;
            background-color: darkgray;
            cursor: pointer;
            outline: none;
        }

        .btn:hover {
            opacity: 0.8;
            transition: 0.5s;
        }

        .error-msg {
            color: #ee0000;
        }

        .error-field {
            border: 1px solid #ee0000;
        }
    </style>
</head>

<body>
    <div class="phppot-container">
        <div class="box-header">
            <h2>Login</h2>
        </div>
        <div class="login-signup">
            <a href="registration.php">Sign up</a>
        </div>
        <form name="login" action="login.php" method="post" onsubmit="return loginValidation()">
            <?php if(!empty($loginResult)){?>
            <div class="error-msg"><?php echo $loginResult;?></div>
            <?php }?>
            <div class="row">
                <div class="form-label">
                    Username<span class="required error" id="username-info"></span>
                </div>
                <input class="input-box-330" type="text" name="username" id="username">
            </div>
            <div class="row">
                <div class="form-label">
                    Password<span class="required error" id="login-password-info"></span>
                </div>
                <input class="input-box-330" type="password" name="login-password" id="login-password">
            </div>
            <div class="row">
                <input class="btn" type="submit" name="login-btn" id="login-btn" value="Login">
            </div>
        </form>
    </div>

    <script>
        function loginValidation() {
            var valid = true;
            $("#username").removeClass("error-field");
            $("#password").removeClass("error-field");

            var UserName = $("#username").val();
            var Password = $('#login-password').val();

            $("#username-info").html("").hide();

            if (UserName.trim() == "") {
                $("#username-info").html("required.").css("color", "#ee0000").show();
                $("#username").addClass("error-field");
                valid = false;
            }
            if (Password.trim() == "") {
                $("#login-password-info").html("required.").css("color", "#ee0000").show();
                $("#login-password").addClass("error-field");
                valid = false;
            }
            if (valid == false) {
                $('.error-field').first().focus();
                valid = false;
            }
            return valid;
        }
    </script>
</body>

</html>
