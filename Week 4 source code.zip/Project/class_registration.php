<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $userPassword = $_POST["password"];
    $address = $_POST["address"];
    $phone = $_POST["phone"];
    $selectedClasses = $_POST["classes"];

    $host = "localhost";
    $username = "root";
    $dbPassword = "";
    $dbname = "employee_website";
    // Display registered classes
    echo '<div class="message success">Registration successful. You are now registered for the following classes:</div>';
    echo '<div class="registered-classes">';
    echo '<ul>';
    foreach ($selectedClasses as $class) {
        echo '<li>' . $class . ' <a href="class_registration.php?delete=' . urlencode($class) . '">Delete</a></li>';
    }
    echo '</ul>';
    echo '</div>';
} elseif ($_SERVER["REQUEST_METHOD"] === "GET" && isset($_GET['delete'])) {
    $classToDelete = $_GET['delete'];

    $host = "localhost";
    $username = "root";
    $dbPassword = "";
    $dbname = "employee_website";

    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

    $conn = new mysqli($host, $username, $dbPassword, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $stmt = $conn->prepare("DELETE FROM registrations WHERE email = ? AND class = ?");
    if ($stmt) {
        $stmt->bind_param("ss", $email, $classToDelete);
        $stmt->execute();
        $stmt->close();
    }

    // Retrieve remaining registered classes from the database
    $registeredClasses = array();
    $query = "SELECT class FROM registrations WHERE email = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    while ($row = $result->fetch_assoc()) {
        $registeredClasses[] = $row["class"];
    }

    $stmt->close();
    $conn->close();

    // Display registered classes after deletion
    echo '<div class="message success">Class successfully deleted.</div>';
    echo '<div class="registered-classes">';
    echo '<ul>';
    foreach ($registeredClasses as $class) {
        echo '<li>' . $class . ' <a href="class_registration.php?delete=' . urlencode($class) . '">Delete</a></li>';
    }
    echo '</ul>';
    echo '</div>';
} else {
    header("Location: index.php");
    exit();
}
?>

<style>
  .message {
    padding: 10px;
    margin-bottom: 10px;
    border-radius: 4px;
    font-weight: bold;
  }

  .success {
    background-color: #4CAF50;
    color: white;
  }

  .error {
    background-color: #f44336;
    color: white;
  }

  .registered-classes {
    margin-top: 20px;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
    background-color: #f9f9f9;
  }

  .registered-classes ul {
    list-style-type: none;
    padding: 0;
  }

  .registered-classes li {
    margin-bottom: 5px;
  }
</style>
