<?php

$servername = "localhost";

$username = "root";

$password = "";

$dbname = "employee_website";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection

if ($conn->connect_error) {

die("Connection failed: " . $conn->connect_error);

}


if($_POST){

$email =$_POST["Email"];

$password =$_POST["Password"];

$firstName = $_POST["FirstName"];

$lastName = $_POST["LastName"];

$address =$_POST["Address"];

$phone =$_POST["Phone"];

$salary =$_POST["Salary"];

$ssn =$_POST["SSN"];

// Create connection

$sql = "INSERT INTO info (salary,email,password,firstName,lastName,address,phone,ssn)

VALUES ('{$salary}', '{$email}', '{$password}', '{$firstName}', '{$lastName}', '{$address}', '{$phone}', '{$ssn}')";

if ($conn->query($sql) === TRUE){

echo "<font color='green'>Information Submitted Successfully</font>";

exit();

}

else {

echo "Error: " . $sql . "<br>" . $conn->error;

}

$conn->close();

}

?>