<!DOCTYPE HTML>
<html>
<head>
    <title>Profile Page</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f3c677;
        }

        div {
            margin: auto;
            margin-top: 3rem;
            border: 1px solid #0c0a3e;
            background: #f3c677;
            width: fit-content;
            padding: 50px;
            border-radius: 5px;
        }

        h2 {
            text-align: center;
            padding-bottom: 1rem;
            color: #b33f62;
        }

        table {
            border: 1px solid #0c0a3e;
            border-radius: 5px;
            padding: 1px;
            margin: 0 auto;
        }

        td {
            color: #b33f62;
            font-weight: 700;
            padding-left: 30px;
            padding-top: 15px;
        }

        input[type="text"],
        input[type="number"],
        input[type="email"],
        input[type="password"],
        textarea {
            width: 180px;
            height: 30px;
            font-size: 15px;
            border-radius: 10px;
            border: 1px solid #0c0a3e;
            padding: 5px;
        }

        input[type="submit"] {
            background-color: #b33f62;
            color: white;
            margin-bottom: 1rem;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #f9564f;
        }
    </style>
</head>

<body>
    <div>
        <h2>User Profile Page</h2>
        <table>
            <form method="post" action="config.php">
                <tr>
                    <td>First Name:</td>
                    <td><input type="text" name="FirstName"></td>
                </tr>
                <tr>
                    <td>Last Name:</td>
                    <td><input type="text" name="LastName"></td>
                </tr>
                <tr>
                    <td>SSN:</td>
                    <td><input type="number" name="SSN"></td>
                </tr>
                <tr>
                    <td>Email:</td>
                    <td><input type="email" name="Email"></td>
                </tr>
                <tr>
                    <td>Password:</td>
                    <td><input type="password" name="Password"></td>
                </tr>
                <tr>
                    <td>Address:</td>
                    <td><textarea name="Address" rows="2"></textarea></td>
                </tr>
                <tr>
                    <td>Phone:</td>
                    <td><input type="number" name="Phone"></td>
                </tr>
                <tr>
                    <td>Salary:</td>
                    <td><input type="number" name="Salary"></td>
                </tr>
                <tr>
                    <td colspan="2"><input type="submit" name="submit"></td>
                </tr>
            </form>
        </table>
    </div>
</body>
</html>
